Wordsmith
=========

Responsive Ghost Theme with a touch of color.

Fonts: Raleway and Noticia Text from Google Fonts.
Iconfonts: Icomoon.io

Personal expermient to understand and practice Ghost Theming

See Wordsmith up and running here: <a href="http://wordsmith.marcosn.com">Running Wordsmith</a>.


Details
=========

Styling: The styling was made using Stylus. (File included)

The core of animations, transitions and effects is within the main.js also included.

Copyright (c) 2013 Marcos Navarro | Released under The MIT License.


Changelog
=========

Look at CHANGELOG.md for the full details


Contributions
=========

Feel free to contribute and report any bug. Thank you.

Also you can find me on marcosn.com and twitter/marcosnwp