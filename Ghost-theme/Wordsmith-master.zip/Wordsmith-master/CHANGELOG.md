# Wordsmith Ghost Theme Changelog

_Showing 3 releases._

## Release 1.0.3

* Added page.hbs for Ghost 0.4
* Added syntax highlight via highlight.js

## Release 1.0.2

* CSS adjustments for images and "pre" & "code" tags.

## Release 1.0.1

* Remove Partials, weren't necessary

## Release 1.0

* First release